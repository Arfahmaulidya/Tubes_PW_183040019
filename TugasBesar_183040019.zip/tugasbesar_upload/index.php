<?php 
require 'functions.php';

$honor = query("SELECT * FROM honor");


// tombol cari ditekan
if(isset($_POST["cari"])) {
	$honor = cari($_POST["keyword"]);
}
 

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		body {
			background-color: #DCD0C0;
		}
		button {
			background-color: aliceblue;
			margin-bottom: 20px;
			border-radius: 5px;
		}
		.ubah {
			background-color: lightskyblue;
			border-radius: 5px;
		}
		.hapus {
			background-color: lightcoral;
			border-radius: 5px;
		}
		h1 {
			text-align: center;
		}
		table {
			text-align: center;
		}
		th {
			background-color: #C0B283;
		}
		td {
			background-color: ;
		}
	</style>
</head>
<body>

	<h1>Produk Honor Terlaris</h1>

	<button><a href="tambah.php">Tambah Data Smartphone</a></button>

	<form action="" method="post">
		
		<input type="text" name="keyword" size="30" placeholder="Cari" autofocus autocomplete="off">
		<button type="submit" name="cari">Cari</button>

	</form>

	<table border="1" cellpadding="10" cellspacing="0">
		
		<tr>
			<th>No</th>
			<th>Gambar</th>
			<th>Nama Smartphone</th>
			<th>Tahun Rilis</th>
			<th>Chipset</th>
			<th>Ram dan Memori</th>
			<th>Kamera</th>
			<th>Baterai</th>
			<th>Harga</th>
			<th>Opsi</th>
		</tr>

		<?php if(empty($honor)) : ?>
			<tr>
				<td colspan="10"> Data tidak ditemukan</td>
			</tr>

		<?php endif; ?>
		<?php $i = 1; ?>
		<?php foreach ($honor as $a) : ?>
		<tr>
			<td><?php echo $i; ?></td>
			<td><img src="img/<?= $a['photo']; ?>" width="100%"></td>
			<td><?= $a['tipe']; ?></td>
			<td><?= $a['tahunrilis']; ?></td>
			<td><?= $a['chipset']; ?></td>
			<td><?= $a['rammemori']; ?></td>
			<td><?= $a['kamera']; ?></td>
			<td><?= $a['baterai']; ?></td>
			<td><?= $a['harga']; ?></td>
			<td>
				<button class="ubah"><a href="ubah.php?id=<?= $a['id']; ?>">Ubah</a></button>
				<button class="hapus"><a href="hapus.php?id=<?= $a['id']; ?>" onclick="return confirm('Apakah anda yakin ingin mengapus data ini?');">Hapus</a></button>
			</td>
		</tr>
		<?php $i++; ?>
	<?php endforeach; ?>
	</table>

</body>
</html>